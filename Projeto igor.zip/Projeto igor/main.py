from flask import Flask, render_template, redirect, url_for, flash, request
import fdb

app = Flask(__name__)

app.config['SECRET_KEY'] = 'Aqui_e_a_chave_do_grupo'

con = fdb.connect(
    host='localhost',
    database=r'C:\Users\mathe\Downloads\BANCO.FDB',
    user='SYSDBA',
    password='sysdba'
)


@app.route('/')
def inicio():
    return render_template('index.html')


@app.route('/produto')
def produto():
    return render_template('paginaproduto.html')


@app.route('/criarconta')
def criarconta():
    return render_template('criarconta.html')


@app.route('/endereco')
def endereco():
    return render_template('endereco.html')


@app.route('/adicionar_endereco', methods=['POST'])
def adicionar_endereco():
    cep = request.form['cep']
    rua = request.form['rua']
    numero = request.form['numero']
    complemento = request.form['complemento'] or None
    nome = request.form['nome']
    telefone = request.form['telefone']

    cursor = con.cursor()

    try:
        cursor.execute("""
            SELECT 1
            FROM endereco
            WHERE nome = ?
            AND rua = ?
            AND numero = ?
        """, (nome, rua, numero))

        if cursor.fetchone():
            flash('Erro: Endereço já cadastrado')
            return redirect(url_for('endereco'))

        cursor.execute("""
            INSERT INTO endereco
            (cep, rua, numero, complemento, nome, telefone)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (cep, rua, numero, complemento, nome, telefone))

        con.commit()

        return redirect(url_for('pagamento'))

    except Exception as e:
        con.rollback()
        flash(f'Ocorreu um erro -> {e}')
        return redirect(url_for('endereco'))

    finally:
        cursor.close()


@app.route('/editar_endereco/<int:id>')
def editar_endereco(id):
    cursor = con.cursor()

    try:
        cursor.execute("""
            SELECT id_endereco, cep, rua, numero, complemento, nome, telefone
            FROM endereco
            WHERE id_endereco = ?
        """, (id,))

        endereco = cursor.fetchone()

        if not endereco:
            flash('Endereço não encontrado')
            return redirect(url_for('pagamento'))

        return render_template(
            'editar_endereco.html',
            endereco=endereco
        )

    finally:
        cursor.close()


@app.route('/atualizar_endereco/<int:id>', methods=['POST'])
def atualizar_endereco(id):
    cep = request.form['cep']
    rua = request.form['rua']
    numero = request.form['numero']
    complemento = request.form['complemento'] or None
    nome = request.form['nome']
    telefone = request.form['telefone']

    cursor = con.cursor()

    try:
        cursor.execute("""
            UPDATE endereco
            SET cep = ?,
                rua = ?,
                numero = ?,
                complemento = ?,
                nome = ?,
                telefone = ?
            WHERE id_endereco = ?
        """, (
            cep,
            rua,
            numero,
            complemento,
            nome,
            telefone,
            id
        ))

        con.commit()

        return redirect(url_for('pagamento'))

    except Exception as e:
        con.rollback()
        flash(f'Ocorreu um erro -> {e}')
        return redirect(url_for('pagamento'))

    finally:
        cursor.close()


@app.route('/pagamento')
def pagamento():
    cursor = con.cursor()

    try:
        cursor.execute("""
            SELECT id_endereco, rua, numero, cep
            FROM endereco
        """)

        enderecos = cursor.fetchall()

        return render_template(
            'pagamento.html',
            enderecos=enderecos
        )

    finally:
        cursor.close()


@app.route('/finalizar')
def finalizar():
    return render_template('pagamento-banco.html')


@app.route('/cadastrar_cartao', methods=['POST'])
def cadastrar_cartao():
    numero_cartao = request.form['numero']
    nome = request.form['nome']
    vencimento = request.form['vencimento']
    codigo = request.form['codigo']
    cpf = request.form['cpf']

    cursor = con.cursor()

    try:
        cursor.execute("""
            SELECT 1
            FROM pagamento
            WHERE numero_cartao = ?
            AND nome = ?
            AND vencimento = ?
            AND codigo = ?
            AND cpf = ?
        """, (
            numero_cartao,
            nome,
            vencimento,
            codigo,
            cpf
        ))

        if cursor.fetchone():
            flash('Erro: Cartão já cadastrado')
            return redirect(url_for('finalizar'))

        cursor.execute("""
            INSERT INTO pagamento
            (numero_cartao, nome, vencimento, codigo, cpf)
            VALUES (?, ?, ?, ?, ?)
        """, (
            numero_cartao,
            nome,
            vencimento,
            codigo,
            cpf
        ))

        con.commit()

        return redirect(url_for('mensagem'))

    except Exception as e:
        con.rollback()
        flash(f'Ocorreu um erro -> {e}')
        return redirect(url_for('finalizar'))

    finally:
        cursor.close()


@app.route('/mensagem')
def mensagem():
    return render_template('mensagem.html')


if __name__ == '__main__':
    app.run(debug=True)